Argus PEP client and server common library
==========================================

Java library shared between the Argus PEP client API and the Argus PEP Server.

Building
--------

Packaging the source:

    make dist

Building the package:

    make package
